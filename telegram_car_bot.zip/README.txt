
✅ Инструкция по запуску Telegram-бота для выкупа автомобилей (Render.com)

1. Перейди на https://render.com и зарегистрируйся (можно через GitHub)
2. Создай новый репозиторий на https://github.com
3. Загрузи туда эти файлы: bot.py, requirements.txt
4. На Render нажми "New" → "Web Service" → выбери свой репозиторий
5. В настройках:
   - Environment: Python
   - Build command: pip install -r requirements.txt
   - Start command: python bot.py
6. Во вкладке Environment добавь переменную:
   - Name: BOT_TOKEN
   - Value: (сюда вставь свой токен бота от @BotFather)

7. Замени в bot.py строку:
   admin_chat_id = 123456789
   — на свой Telegram ID (узнать ID можно у @userinfobot)

После этого бот будет работать круглосуточно!
