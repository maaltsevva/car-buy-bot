
import os
from telegram import Update, InputMediaPhoto
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    ContextTypes, ConversationHandler, filters
)

CAR_INFO, MILEAGE, PHOTOS, CONTACT = range(4)

admin_chat_id = 123456789  # ← замени на свой Telegram ID
BOT_TOKEN = os.getenv("BOT_TOKEN")  # безопасное хранение токена

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я помогу продать твой автомобиль. Введи марку, модель и год выпуска:")
    return CAR_INFO

async def car_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["car_info"] = update.message.text
    await update.message.reply_text("Укажи пробег:")
    return MILEAGE

async def mileage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["mileage"] = update.message.text
    await update.message.reply_text("Пришли фото автомобиля:")
    return PHOTOS

async def photos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if "photos" not in context.user_data:
        context.user_data["photos"] = []
    photo = update.message.photo[-1].file_id
    context.user_data["photos"].append(photo)
    await update.message.reply_text("Если закончил с фото — отправь свой номер телефона:")
    return CONTACT

async def contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["contact"] = update.message.text
    await update.message.reply_text("Заявка принята! Мы скоро свяжемся с вами.")
    text = (
        f"🚘 Новая заявка на выкуп авто:\n"
        f"Автомобиль: {context.user_data['car_info']}\n"
        f"Пробег: {context.user_data['mileage']}\n"
        f"Контакт: {context.user_data['contact']}"
    )
    await context.bot.send_message(chat_id=admin_chat_id, text=text)
    if "photos" in context.user_data:
        media = [InputMediaPhoto(photo) for photo in context.user_data["photos"]]
        await context.bot.send_media_group(chat_id=admin_chat_id, media=media)
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Заявка отменена.")
    return ConversationHandler.END

app = ApplicationBuilder().token(BOT_TOKEN).build()

conv_handler = ConversationHandler(
    entry_points=[CommandHandler("start", start)],
    states={
        CAR_INFO: [MessageHandler(filters.TEXT & ~filters.COMMAND, car_info)],
        MILEAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, mileage)],
        PHOTOS: [MessageHandler(filters.PHOTO, photos)],
        CONTACT: [MessageHandler(filters.TEXT & ~filters.COMMAND, contact)],
    },
    fallbacks=[CommandHandler("cancel", cancel)],
)

app.add_handler(conv_handler)

print("Бот запущен...")
app.run_polling()
